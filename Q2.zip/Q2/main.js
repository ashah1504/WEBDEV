// Setup

let stringCont = document.getElementById("str-var");
let intCont = document.getElementById("int-var");
let AddF_soln = document.getElementById("AddF-soln");
let if_elseAns = document.getElementById("if-else-header-answer");

// Variables
let stringVar = "Aashna";
stringCont.innerHTML = stringVar;
let integerVar = 42;
intCont.innerHTML = integerVar;

// Addition function
let AddF = (num1, num2) => {
    return num1 + num2;
};

// Setting the output of the function to html content
AddF_soln.innerHTML = AddF(17, 13);

// Decision making
let student_status = "student";
if (student_status === "student") {
    if_elseAns.innerHTML = "Yes!";
} else {
    if_elseAns.innerHTML = "No!";
}

// Loop to print multiples of 5
for (let i = 1; i < 11; i++) {
    document.write(i * 5 + "<br>");
}